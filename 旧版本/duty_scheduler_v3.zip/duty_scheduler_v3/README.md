# 社团值班排班器 V3

V3 目标：保留第一版更好用的图形化前端，同时保留 V2 的“最大可行排班”逻辑。

## 本版时间范围

- 周：`1` 到 `7`
  - `1` 周一
  - `2` 周二
  - `3` 周三
  - `4` 周四
  - `5` 周五
  - `6` 周六
  - `7` 周日
- 值班段：`1` 到 `6`

## 支持功能

- 图形化设置开班/不开班时段
- 图形化新增、删除成员
- 图形化勾选每个成员的课表
- 每个成员设置“优先多排 / 正常 / 优先少排”
- 每个成员设置禁排日期
- 每人每周最多排一次
- 每个开班时段最多一个人
- 只在没课时间排班
- 能排多少排多少，返回最大可行排班
- 导出 JSON
- 安装 `openpyxl` 后可导出 Excel

## 输出语义

- `success: true`：程序正常算出了结果
- `all_filled: true`：所有开班时段都排满
- `all_filled: false`：只能排满一部分
- `status`
  - `full`：全部排满
  - `partial`：部分排满
  - `empty`：一个班都没排上

注意：无法全部排满不是程序失败，而是当前约束下只能得到部分可行解。

## JSON 输入格式

```json
{
  "config": {
    "open_shifts": {
      "1": {"1": 1, "2": 0, "3": 1, "4": 1, "5": 0, "6": 0},
      "2": {"1": 0, "2": 1, "3": 1, "4": 0, "5": 1, "6": 0},
      "3": {"1": 0, "2": 0, "3": 1, "4": 1, "5": 1, "6": 0},
      "4": {"1": 0, "2": 0, "3": 1, "4": 0, "5": 1, "6": 1},
      "5": {"1": 0, "2": 0, "3": 0, "4": 1, "5": 1, "6": 1},
      "6": {"1": 1, "2": 1, "3": 1, "4": 0, "5": 0, "6": 0},
      "7": {"1": 1, "2": 1, "3": 0, "4": 0, "5": 0, "6": 0}
    }
  },
  "members": [
    {
      "name": "张三",
      "priority": "prefer_more",
      "ban_days": ["5"],
      "schedule": {
        "1": {"1": 1, "2": 1, "3": 0, "4": 0, "5": 0, "6": 1},
        "2": {"1": 0, "2": 1, "3": 0, "4": 0, "5": 1, "6": 0},
        "3": {"1": 0, "2": 0, "3": 1, "4": 1, "5": 0, "6": 0},
        "4": {"1": 1, "2": 0, "3": 0, "4": 0, "5": 0, "6": 1},
        "5": {"1": 0, "2": 0, "3": 1, "4": 0, "5": 0, "6": 0},
        "6": {"1": 1, "2": 0, "3": 0, "4": 1, "5": 0, "6": 0},
        "7": {"1": 0, "2": 0, "3": 0, "4": 0, "5": 1, "6": 0}
      }
    }
  ]
}
```

## 字段说明

- `config.open_shifts[day][slot]`
  - `1`：该时段开班，需要排人
  - `0`：该时段不开班
- `members[].schedule[day][slot]`
  - `0`：没课，可以值班
  - `1`：有课，不能值班
- `priority`
  - `prefer_more`：优先多排
  - `normal`：正常
  - `prefer_less`：优先少排
- `ban_days`
  - 例如 `["2", "5"]` 表示此成员周二、周五整天不能排班

## 命令行使用

```bash
pip install -r requirements.txt
python app.py tests/inputs/case_full_fill_realistic.json --json result.json --xlsx result.xlsx
```

如果只需要 JSON，不需要 Excel：

```bash
python app.py tests/inputs/case_full_fill_realistic.json --json result.json
```

## 启动网页表单

```bash
pip install -r requirements.txt
python app.py --web
```

浏览器打开：

```text
http://127.0.0.1:5000
```

## 运行测试

```bash
python run_tests.py
```

测试集包括：

- `case_full_fill_realistic.json`：复杂但能全部排满
- `case_partial_fill_realistic.json`：只能部分排满
- `case_priority_realistic.json`：验证优先多排/少排

## 备注

旧字段 `require_open_shift_count_less_than_member_count` 已废弃。现在程序不会因为开班数和人数关系直接拒绝，而是总是尝试返回当前约束下的最大可行排班。

import json
import os
import uuid
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Tuple

try:
    from flask import Flask, jsonify, render_template, request, send_from_directory
except ModuleNotFoundError:
    Flask = None
    jsonify = None
    render_template = None
    request = None
    send_from_directory = None

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

DAYS = ["2", "3", "4", "5", "6", "7"]
SLOTS = ["0", "1", "2", "3"]
PRIORITY_COST = {
    "prefer_more": -20,
    "normal": 0,
    "prefer_less": 20,
}
DAY_NAME = {
    "2": "周二",
    "3": "周三",
    "4": "周四",
    "5": "周五",
    "6": "周六",
    "7": "周日",
}


@dataclass
class Edge:
    to: int
    rev: int
    cap: int
    cost: int


class MinCostMaxFlow:
    def __init__(self, n: int) -> None:
        self.n = n
        self.graph: List[List[Edge]] = [[] for _ in range(n)]

    def add_edge(self, fr: int, to: int, cap: int, cost: int) -> None:
        fwd = Edge(to=to, rev=len(self.graph[to]), cap=cap, cost=cost)
        rev = Edge(to=fr, rev=len(self.graph[fr]), cap=0, cost=-cost)
        self.graph[fr].append(fwd)
        self.graph[to].append(rev)

    def min_cost_max_flow(self, s: int, t: int) -> Tuple[int, int, List[List[Edge]]]:
        flow = 0
        cost = 0
        while True:
            dist = [10**18] * self.n
            inq = [False] * self.n
            prev_v = [-1] * self.n
            prev_e = [-1] * self.n
            dist[s] = 0
            q = [s]
            inq[s] = True
            head = 0
            while head < len(q):
                v = q[head]
                head += 1
                inq[v] = False
                for i, e in enumerate(self.graph[v]):
                    if e.cap <= 0:
                        continue
                    nd = dist[v] + e.cost
                    if nd < dist[e.to]:
                        dist[e.to] = nd
                        prev_v[e.to] = v
                        prev_e[e.to] = i
                        if not inq[e.to]:
                            q.append(e.to)
                            inq[e.to] = True
            if dist[t] == 10**18:
                break
            addf = 10**18
            v = t
            while v != s:
                u = prev_v[v]
                e = self.graph[u][prev_e[v]]
                addf = min(addf, e.cap)
                v = u
            v = t
            while v != s:
                u = prev_v[v]
                ei = prev_e[v]
                e = self.graph[u][ei]
                e.cap -= addf
                self.graph[v][e.rev].cap += addf
                v = u
            flow += addf
            cost += addf * dist[t]
        return flow, cost, self.graph


class ValidationError(Exception):
    pass


def default_open_shifts() -> Dict[str, Dict[str, int]]:
    return {day: {slot: 1 for slot in SLOTS} for day in DAYS}


def normalize_input(data: dict) -> dict:
    if not isinstance(data, dict):
        raise ValidationError("输入必须是 JSON 对象")

    config = deepcopy(data.get("config", {}))
    open_shifts = config.get("open_shifts", default_open_shifts())
    strict_less = config.get("require_open_shift_count_less_than_member_count", True)
    members = data.get("members")

    if not isinstance(members, list) or not members:
        raise ValidationError("members 必须是非空数组")

    names = set()
    normalized_members = []

    for member in members:
        if not isinstance(member, dict):
            raise ValidationError("每个成员都必须是对象")
        name = str(member.get("name", "")).strip()
        if not name:
            raise ValidationError("每个成员都必须提供非空 name")
        if name in names:
            raise ValidationError(f"成员姓名重复：{name}")
        names.add(name)

        priority = member.get("priority", "normal")
        if priority not in PRIORITY_COST:
            raise ValidationError(
                f"成员 {name} 的 priority 必须是 prefer_more / normal / prefer_less"
            )

        ban_days = member.get("ban_days", [])
        if not isinstance(ban_days, list):
            raise ValidationError(f"成员 {name} 的 ban_days 必须是数组")
        ban_days = [str(day) for day in ban_days]
        for day in ban_days:
            if day not in DAYS:
                raise ValidationError(f"成员 {name} 的 ban_days 包含非法日期：{day}")

        schedule = member.get("schedule")
        if not isinstance(schedule, dict):
            raise ValidationError(f"成员 {name} 的 schedule 必须是对象")

        normalized_schedule = {}
        for day in DAYS:
            if day not in schedule or not isinstance(schedule[day], dict):
                raise ValidationError(f"成员 {name} 缺少 schedule['{day}']")
            normalized_schedule[day] = {}
            for slot in SLOTS:
                if slot not in schedule[day]:
                    raise ValidationError(f"成员 {name} 缺少 schedule['{day}']['{slot}']")
                value = schedule[day][slot]
                if value not in (0, 1):
                    raise ValidationError(
                        f"成员 {name} 在 day={day}, slot={slot} 的值必须是 0 或 1"
                    )
                normalized_schedule[day][slot] = int(value)

        normalized_members.append(
            {
                "name": name,
                "priority": priority,
                "ban_days": ban_days,
                "schedule": normalized_schedule,
            }
        )

    normalized_open_shifts = {}
    if not isinstance(open_shifts, dict):
        raise ValidationError("config.open_shifts 必须是对象")
    for day in DAYS:
        if day not in open_shifts or not isinstance(open_shifts[day], dict):
            raise ValidationError(f"config.open_shifts 缺少 '{day}'")
        normalized_open_shifts[day] = {}
        for slot in SLOTS:
            if slot not in open_shifts[day]:
                raise ValidationError(f"config.open_shifts['{day}'] 缺少 '{slot}'")
            value = open_shifts[day][slot]
            if value not in (0, 1):
                raise ValidationError(
                    f"config.open_shifts 在 day={day}, slot={slot} 的值必须是 0 或 1"
                )
            normalized_open_shifts[day][slot] = int(value)

    normalized = {
        "config": {
            "open_shifts": normalized_open_shifts,
            "require_open_shift_count_less_than_member_count": bool(strict_less),
        },
        "members": normalized_members,
    }
    return normalized


def get_open_shift_list(data: dict) -> List[Tuple[str, str]]:
    result = []
    for day in DAYS:
        for slot in SLOTS:
            if data["config"]["open_shifts"][day][slot] == 1:
                result.append((day, slot))
    return result


def member_can_take_shift(member: dict, day: str, slot: str) -> bool:
    if day in member["ban_days"]:
        return False
    if member["schedule"][day][slot] == 1:
        return False
    return True


def build_candidate_map(data: dict, shifts: List[Tuple[str, str]]) -> Dict[Tuple[str, str], List[str]]:
    candidate_map: Dict[Tuple[str, str], List[str]] = {}
    for day, slot in shifts:
        candidate_map[(day, slot)] = [
            member["name"]
            for member in data["members"]
            if member_can_take_shift(member, day, slot)
        ]
    return candidate_map


def solve_schedule(data: dict) -> dict:
    data = normalize_input(data)
    members = data["members"]
    shifts = get_open_shift_list(data)

    total_members = len(members)
    total_open_shifts = len(shifts)

    if data["config"]["require_open_shift_count_less_than_member_count"]:
        if total_open_shifts >= total_members:
            raise ValidationError(
                f"当前开启班次数为 {total_open_shifts}，成员数为 {total_members}，必须满足 开启班次数 < 成员数"
            )

    candidate_map = build_candidate_map(data, shifts)
    no_candidate_shifts = [
        {"day": day, "slot": slot}
        for (day, slot), candidates in candidate_map.items()
        if not candidates
    ]

    shift_index = {shift: idx for idx, shift in enumerate(shifts)}
    member_index = {member["name"]: idx for idx, member in enumerate(members)}

    source = 0
    shift_offset = 1
    member_offset = shift_offset + len(shifts)
    sink = member_offset + len(members)
    mcmf = MinCostMaxFlow(sink + 1)

    for shift, idx in shift_index.items():
        mcmf.add_edge(source, shift_offset + idx, 1, 0)

    for shift, idx in shift_index.items():
        day, slot = shift
        for member_name in candidate_map[(day, slot)]:
            midx = member_index[member_name]
            mcmf.add_edge(shift_offset + idx, member_offset + midx, 1, 0)

    for member in members:
        midx = member_index[member["name"]]
        cost = PRIORITY_COST[member["priority"]]
        mcmf.add_edge(member_offset + midx, sink, 1, cost)

    flow, total_cost, graph = mcmf.min_cost_max_flow(source, sink)

    assignments = []
    matched_members = set()
    shift_to_person: Dict[Tuple[str, str], Optional[str]] = {shift: None for shift in shifts}

    for shift, sidx in shift_index.items():
        node = shift_offset + sidx
        for edge in graph[node]:
            if member_offset <= edge.to < sink and edge.cap == 0:
                member_name = members[edge.to - member_offset]["name"]
                shift_to_person[shift] = member_name
                matched_members.add(member_name)
                assignments.append(
                    {
                        "day": shift[0],
                        "slot": shift[1],
                        "person": member_name,
                    }
                )
                break

    assignments.sort(key=lambda item: (item["day"], item["slot"]))

    duty_table = {day: {slot: None for slot in SLOTS} for day in DAYS}
    closed_shifts = []
    for day in DAYS:
        for slot in SLOTS:
            if data["config"]["open_shifts"][day][slot] == 0:
                duty_table[day][slot] = "不开班"
                closed_shifts.append({"day": day, "slot": slot})

    for item in assignments:
        duty_table[item["day"]][item["slot"]] = item["person"]

    unfilled_shifts = [
        {"day": day, "slot": slot}
        for (day, slot), person in shift_to_person.items()
        if person is None
    ]

    unassigned_members = [
        member["name"] for member in members if member["name"] not in matched_members
    ]

    priority_summary = {
        "prefer_more_assigned": sum(
            1
            for member in members
            if member["priority"] == "prefer_more" and member["name"] in matched_members
        ),
        "prefer_less_assigned": sum(
            1
            for member in members
            if member["priority"] == "prefer_less" and member["name"] in matched_members
        ),
    }

    success = len(unfilled_shifts) == 0
    return {
        "success": success,
        "message": "排班完成" if success else "已给出当前约束下的最大可行排班，但仍有未填满班次",
        "summary": {
            "total_members": total_members,
            "open_shift_count": total_open_shifts,
            "assigned_shift_count": len(assignments),
            "unfilled_shift_count": len(unfilled_shifts),
            "closed_shift_count": len(closed_shifts),
            "unassigned_member_count": len(unassigned_members),
            "priority_summary": priority_summary,
            "optimization_cost": total_cost,
        },
        "assignments": assignments,
        "duty_table": duty_table,
        "closed_shifts": closed_shifts,
        "unfilled_shifts": unfilled_shifts,
        "unassigned_members": unassigned_members,
        "no_candidate_shifts": no_candidate_shifts,
        "normalized_input": data,
    }


def autosize_worksheet(ws) -> None:
    widths: Dict[int, int] = {}
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is None:
                continue
            value = str(cell.value)
            widths[cell.column] = max(widths.get(cell.column, 0), len(value) + 2)
    for col_idx, width in widths.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(width, 10), 24)


def export_excel(result: dict, output_path: str) -> None:
    wb = Workbook()
    ws_summary = wb.active
    ws_summary.title = "Summary"

    title_fill = PatternFill("solid", fgColor="D9EAF7")
    header_fill = PatternFill("solid", fgColor="EEF5FB")
    title_font = Font(bold=True, size=14)
    header_font = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center")

    ws_summary["A1"] = "排班结果汇总"
    ws_summary["A1"].font = title_font
    summary_rows = [
        ("成功", "是" if result["success"] else "否"),
        ("说明", result["message"]),
        ("成员总数", result["summary"]["total_members"]),
        ("开启班次数", result["summary"]["open_shift_count"]),
        ("已排班次数", result["summary"]["assigned_shift_count"]),
        ("未填满班次数", result["summary"]["unfilled_shift_count"]),
        ("不开班次数", result["summary"]["closed_shift_count"]),
        ("未排成员数", result["summary"]["unassigned_member_count"]),
        ("优先多排实际排到人数", result["summary"]["priority_summary"]["prefer_more_assigned"]),
        ("优先少排实际排到人数", result["summary"]["priority_summary"]["prefer_less_assigned"]),
    ]
    for i, (k, v) in enumerate(summary_rows, start=3):
        ws_summary[f"A{i}"] = k
        ws_summary[f"B{i}"] = v
        ws_summary[f"A{i}"].font = header_font
    ws_summary.column_dimensions["A"].width = 22
    ws_summary.column_dimensions["B"].width = 30

    ws_table = wb.create_sheet("DutyTable")
    ws_table["A1"] = "值班总表"
    ws_table["A1"].font = title_font
    headers = ["日期/班次"] + SLOTS
    for col, text in enumerate(headers, start=1):
        cell = ws_table.cell(row=3, column=col, value=text)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center
    for r, day in enumerate(DAYS, start=4):
        ws_table.cell(row=r, column=1, value=DAY_NAME[day]).fill = header_fill
        ws_table.cell(row=r, column=1).font = header_font
        ws_table.cell(row=r, column=1).alignment = center
        for c, slot in enumerate(SLOTS, start=2):
            value = result["duty_table"][day][slot]
            ws_table.cell(row=r, column=c, value=value)
            ws_table.cell(row=r, column=c).alignment = center

    ws_assign = wb.create_sheet("Assignments")
    ws_assign["A1"] = "已分配班次"
    ws_assign["A1"].font = title_font
    assign_headers = ["星期", "班次", "成员"]
    for c, text in enumerate(assign_headers, start=1):
        cell = ws_assign.cell(row=3, column=c, value=text)
        cell.fill = header_fill
        cell.font = header_font
    for r, item in enumerate(result["assignments"], start=4):
        ws_assign.cell(row=r, column=1, value=DAY_NAME[item["day"]])
        ws_assign.cell(row=r, column=2, value=item["slot"])
        ws_assign.cell(row=r, column=3, value=item["person"])

    ws_members = wb.create_sheet("UnassignedMembers")
    ws_members["A1"] = "未排班成员"
    ws_members["A1"].font = title_font
    ws_members["A3"] = "成员"
    ws_members["A3"].fill = header_fill
    ws_members["A3"].font = header_font
    for r, name in enumerate(result["unassigned_members"], start=4):
        ws_members.cell(row=r, column=1, value=name)

    ws_input = wb.create_sheet("InputSnapshot")
    ws_input["A1"] = "输入快照（JSON）"
    ws_input["A1"].font = title_font
    snapshot = json.dumps(result["normalized_input"], ensure_ascii=False, indent=2)
    ws_input["A3"] = snapshot
    ws_input["A3"].alignment = Alignment(wrap_text=True, vertical="top")
    ws_input.column_dimensions["A"].width = 120
    ws_input.row_dimensions[3].height = 400

    for ws in [ws_summary, ws_table, ws_assign, ws_members]:
        autosize_worksheet(ws)

    wb.save(output_path)


def save_outputs(result: dict, export_dir: str) -> dict:
    os.makedirs(export_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    token = uuid.uuid4().hex[:8]
    json_name = f"schedule_{stamp}_{token}.json"
    xlsx_name = f"schedule_{stamp}_{token}.xlsx"
    json_path = os.path.join(export_dir, json_name)
    xlsx_path = os.path.join(export_dir, xlsx_name)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    export_excel(result, xlsx_path)
    return {
        "json_name": json_name,
        "xlsx_name": xlsx_name,
        "json_path": json_path,
        "xlsx_path": xlsx_path,
    }


EXPORT_DIR = os.path.join(os.path.dirname(__file__), "exports")
app = Flask(__name__) if Flask is not None else None

if app is not None:

    @app.route("/")
    def index():
        return render_template("index.html", days=DAYS, slots=SLOTS, day_name=DAY_NAME)


    @app.route("/api/schedule", methods=["POST"])
    def api_schedule():
        try:
            data = request.get_json(force=True)
            result = solve_schedule(data)
            files = save_outputs(result, EXPORT_DIR)
            return jsonify(
                {
                    "ok": True,
                    "result": result,
                    "downloads": {
                        "json": f"/downloads/{files['json_name']}",
                        "xlsx": f"/downloads/{files['xlsx_name']}",
                    },
                }
            )
        except ValidationError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        except Exception as e:
            return jsonify({"ok": False, "error": f"服务器错误：{e}"}), 500


    @app.route("/downloads/<path:filename>")
    def download_file(filename: str):
        return send_from_directory(EXPORT_DIR, filename, as_attachment=True)


def run_cli(input_path: str, output_json: Optional[str], output_xlsx: Optional[str]) -> None:
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    result = solve_schedule(data)
    if output_json:
        with open(output_json, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    if output_xlsx:
        export_excel(result, output_xlsx)
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    if output_json:
        print(f"JSON 已输出到: {output_json}")
    if output_xlsx:
        print(f"Excel 已输出到: {output_xlsx}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="社团值班排班器")
    parser.add_argument("input", nargs="?", help="输入 JSON 文件路径")
    parser.add_argument("--json", dest="output_json", help="输出 JSON 文件路径")
    parser.add_argument("--xlsx", dest="output_xlsx", help="输出 Excel 文件路径")
    parser.add_argument("--web", action="store_true", help="启动网页表单")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    if args.web:
        if app is None:
            raise SystemExit("当前环境未安装 Flask，请先执行: pip install flask")
        app.run(host=args.host, port=args.port, debug=True)
    else:
        if not args.input:
            raise SystemExit("CLI 模式下必须提供 input.json，或者使用 --web 启动网页表单")
        run_cli(args.input, args.output_json, args.output_xlsx)

# 社团值班排班器

支持这些功能：

- 指定某些时段不开班
- 指定某些成员优先少排 / 优先多排
- 指定某人不能排某一天
- 导出 JSON 和 Excel
- 本地网页表单录入和生成结果

## 统一 JSON 输入格式

```json
{
  "config": {
    "open_shifts": {
      "2": { "0": 1, "1": 1, "2": 0, "3": 0 },
      "3": { "0": 1, "1": 1, "2": 0, "3": 0 },
      "4": { "0": 1, "1": 0, "2": 0, "3": 0 },
      "5": { "0": 1, "1": 0, "2": 0, "3": 0 },
      "6": { "0": 0, "1": 0, "2": 0, "3": 0 },
      "7": { "0": 0, "1": 0, "2": 0, "3": 0 }
    },
    "require_open_shift_count_less_than_member_count": true
  },
  "members": [
    {
      "name": "张三",
      "priority": "prefer_more",
      "ban_days": ["5"],
      "schedule": {
        "2": { "0": 0, "1": 1, "2": 0, "3": 0 },
        "3": { "0": 0, "1": 0, "2": 1, "3": 1 },
        "4": { "0": 1, "1": 0, "2": 0, "3": 0 },
        "5": { "0": 0, "1": 0, "2": 0, "3": 1 },
        "6": { "0": 1, "1": 1, "2": 0, "3": 0 },
        "7": { "0": 0, "1": 0, "2": 1, "3": 0 }
      }
    }
  ]
}
```

## 字段说明

- `config.open_shifts`
  - 值为 `1`：这个时段开班，需要排人
  - 值为 `0`：这个时段不开班
- `config.require_open_shift_count_less_than_member_count`
  - `true`：强制检查“开班总次数 < 成员总数”
  - `false`：不做这个检查
- `members[].priority`
  - `prefer_more`：优先多排
  - `normal`：正常
  - `prefer_less`：优先少排
- `members[].ban_days`
  - 例如 `['2', '5']` 表示这个人不能在周二、周五被排班
- `members[].schedule`
  - `0`：没课，可以排
  - `1`：有课，不能排

## 统一 JSON 输出格式

结果里主要包含：

- `success`：是否全部开班时段都成功安排
- `summary`：统计信息
- `assignments`：已排到的班次列表
- `duty_table`：完整总表
- `closed_shifts`：不开班时段
- `unfilled_shifts`：仍未填满的时段
- `unassigned_members`：本周未被安排的成员

## 安装

```bash
pip install -r requirements.txt
```

## 命令行使用

```bash
python app.py sample_input.json --json result.json --xlsx result.xlsx
```

## 启动网页表单

```bash
python app.py --web
```

然后浏览器打开：

```text
http://127.0.0.1:5000
```

## 算法说明

程序使用的是“最大流最小费用”思路：

- 先尽量让更多开班时段被填满
- 在都合法的前提下，优先选择 `prefer_more`
- 尽量少选择 `prefer_less`
- 每个人最多只会被分配一次

## Excel 导出内容

导出的 Excel 包括这些工作表：

- `Summary`：汇总信息
- `DutyTable`：值班总表
- `Assignments`：具体分配结果
- `UnassignedMembers`：未排班成员
- `InputSnapshot`：输入 JSON 快照

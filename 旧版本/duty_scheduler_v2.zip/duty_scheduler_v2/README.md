# 社团值班排班器 V2

这是第二版完整包，重点修了两个逻辑问题：

1. **程序总是返回最大可行排班**
   - 即使无法全部排满，也会返回“部分可行解”
   - 不再把“没全排满”当成程序失败
2. **废弃 `require_open_shift_count_less_than_member_count`**
   - 这条规则在实际排班里不必要
   - 现在即使这个字段还出现在输入里，也只会给出提示，不会拦截计算

## 输出语义

- `success: true`
  - 表示程序正常运行并返回结果
- `all_filled: true/false`
  - 表示是否全部开班时段都排满
- `status`
  - `full`：全部排满
  - `partial`：只排满一部分
  - `empty`：一个都没排上

## JSON 输入格式

```json
{
  "config": {
    "open_shifts": {
      "2": {"1": 1, "2": 0, "3": 0, "4": 1},
      "3": {"1": 0, "2": 0, "3": 1, "4": 0},
      "4": {"1": 0, "2": 1, "3": 0, "4": 0},
      "5": {"1": 0, "2": 0, "3": 0, "4": 0},
      "6": {"1": 1, "2": 0, "3": 0, "4": 1},
      "7": {"1": 0, "2": 0, "3": 0, "4": 0}
    }
  },
  "members": [
    {
      "name": "张三",
      "priority": "prefer_more",
      "ban_days": ["5"],
      "schedule": {
        "2": {"1": 1, "2": 0, "3": 0, "4": 0},
        "3": {"1": 0, "2": 1, "3": 1, "4": 0},
        "4": {"1": 0, "2": 0, "3": 0, "4": 0},
        "5": {"1": 0, "2": 0, "3": 1, "4": 0},
        "6": {"1": 1, "2": 0, "3": 0, "4": 0},
        "7": {"1": 0, "2": 1, "3": 0, "4": 0}
      }
    }
  ]
}
```

### 字段说明

- `open_shifts`
  - `1` = 这个时段开班
  - `0` = 这个时段不开班
- `priority`
  - `prefer_more` = 优先多排
  - `normal` = 正常
  - `prefer_less` = 优先少排
- `ban_days`
  - 这个成员整天不能被排班
- `schedule`
  - `0` = 没课，可以值班
  - `1` = 有课，不能值班

## 算法说明

程序使用“**最大流最小费用**”思想：

- 先尽量让更多开班时段被填满
- 在都合法的前提下：
  - 优先选择 `prefer_more`
  - 尽量少选择 `prefer_less`
- 每个成员每周最多 1 次
- 每个班次最多 1 人

## 复杂测试集

本包自带 3 组更接近真实社团场景的测试数据：

1. `case_full_fill_realistic.json`
   - 6 个开班时段，8 名成员
   - 能全部排满
2. `case_partial_fill_realistic.json`
   - 8 个开班时段，8 名成员
   - 其中 1 个时段完全没人可排
   - 程序会返回 **partial**，而不是报错
3. `case_priority_realistic.json`
   - 所有人都能排，但存在优先级竞争
   - 用来验证 `prefer_more / prefer_less` 是否生效

## 运行方式

安装依赖：

```bash
pip install -r requirements.txt
```

### 命令行

```bash
python app.py tests/inputs/case_partial_fill_realistic.json --json out.json --xlsx out.xlsx
```

### 跑完整测试

```bash
python run_tests.py
```

### 网页表单

```bash
python app.py --web
```

然后打开：

```text
http://127.0.0.1:5000
```

## 目录结构

```text
app.py
run_tests.py
requirements.txt
README.md
templates/index.html
tests/
  inputs/
  manifests/
  generated_outputs/
```

## 识别图片到 JSON 的提示词

包里没有强绑识图模块，但建议在前置多模态识别阶段使用这条规则：

- 只输出 JSON
- 只输出 `members`
- 每天键必须是 `2~7`
- 班次键必须是 `1~4`
- 不确定时默认填 `1`

这样识别出的 JSON 可以直接喂给本程序。

import json
from pathlib import Path

from app import solve_schedule

BASE = Path(__file__).resolve().parent
INPUT_DIR = BASE / 'tests' / 'inputs'
MANIFEST_DIR = BASE / 'tests' / 'manifests'
GENERATED_DIR = BASE / 'tests' / 'generated_outputs'


def assert_invariants(result: dict) -> None:
    assert result['success'] is True
    seen_people = set()
    seen_shift = set()
    for item in result['assignments']:
        shift = (item['day'], item['slot'])
        person = item['person']
        assert shift not in seen_shift, f'班次重复分配: {shift}'
        assert person not in seen_people, f'成员重复排班: {person}'
        seen_shift.add(shift)
        seen_people.add(person)
    assert result['summary']['assigned_shift_count'] == len(result['assignments'])
    assert result['summary']['unfilled_shift_count'] == len(result['unfilled_shifts'])
    assert result['summary']['unassigned_member_count'] == len(result['unassigned_members'])


def run_one(manifest_path: Path) -> None:
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    input_path = INPUT_DIR / manifest['input']
    data = json.loads(input_path.read_text(encoding='utf-8'))
    result = solve_schedule(data)
    assert_invariants(result)
    expected = manifest['expected']
    assert result['status'] == expected['status']
    assert result['all_filled'] == expected['all_filled']
    assert result['summary']['assigned_shift_count'] == expected['assigned_shift_count']
    assert result['summary']['unfilled_shift_count'] == expected['unfilled_shift_count']
    assert result['summary']['open_shift_count'] == expected['open_shift_count']
    if 'no_candidate_shifts_count' in expected:
        assert len(result['no_candidate_shifts']) == expected['no_candidate_shifts_count']
    if 'prefer_more_assigned_min' in expected:
        assert result['summary']['priority_summary']['prefer_more_assigned'] >= expected['prefer_more_assigned_min']

    GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    out_path = GENERATED_DIR / (manifest_path.stem.replace('.manifest', '') + '.verified.json')
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'[PASS] {manifest_path.name}')


if __name__ == '__main__':
    manifests = sorted(MANIFEST_DIR.glob('*.json'))
    for manifest in manifests:
        run_one(manifest)
    print(f'共通过 {len(manifests)} 组测试。')
